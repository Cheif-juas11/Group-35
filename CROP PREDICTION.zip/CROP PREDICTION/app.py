from flask import Flask, request, jsonify
import pickle
import pandas as pd
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Load the trained model and scaler
model = pickle.load(open('model/model.sav', 'rb'))
scaler = pickle.load(open('scaler.pkl', 'rb'))

# Define the prediction function
def predict_yield(input_data):
    try:
        # One-hot encode 'Country' and 'Item'
        input_data = pd.get_dummies(input_data, columns=['Country', 'Item'])

        # Ensure that the input has the same columns as the model was trained on
        all_columns = scaler.feature_names_in_  # Get the columns used during scaling
        input_data = input_data.reindex(columns=all_columns, fill_value=0)

        # Apply scaling
        input_data_scaled = scaler.transform(input_data)

        # Predict using the trained model
        yield_predicted = model.predict(input_data_scaled)

        return yield_predicted[0]

    except Exception as e:
        return str(e)

# API route for prediction
@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()

    country = data.get('Country')
    item = data.get('Item')
    avg_rainfall = data.get('Avg_Rainfall')
    avg_temp = data.get('Avg_Temperature')
    pesticides_tonnes = data.get('Pesticides_Tonnes')

    # Create a DataFrame for the input data
    input_data = pd.DataFrame({
        'Country': [country],
        'Item': [item],
        'Avg_Rainfall': [avg_rainfall],
        'Avg_Temperature': [avg_temp],
        'Pesticides_Tonnes': [pesticides_tonnes]
    })

    # Get the prediction
    predicted_yield = predict_yield(input_data)

    return jsonify({"predicted_yield": predicted_yield})

if __name__ == '__main__':
    app.run(debug=True)
